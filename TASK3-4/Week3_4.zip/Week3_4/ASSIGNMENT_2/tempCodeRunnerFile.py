def compare_lists():
    list1 = list(map(int, input("Enter numbers for list 1 separated by spaces: ").split()))
    list2 = list(map(int, input("Enter numbers for list 2 separated by spaces: ").split()))
    print("Lists have the same length:", len(list1) == len(list2))
    print("Lists sum to the same value:", sum(list1) == sum(list2))
    print("Common values:", set(list1) & set(list2))


compare_lists()