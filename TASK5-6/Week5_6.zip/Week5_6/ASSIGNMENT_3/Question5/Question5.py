def count_words(filename):
    try:
        with open(filename, 'r', encoding='utf-8') as file:
            text = file.read().lower()  # Read and convert to lowercase
            words = text.split()  # Split into words

            word_count = {}
            for word in words:
                # Remove punctuation from each word
                word = ''.join(char for char in word if char.isalnum())

                if word:
                    word_count[word] = word_count.get(word, 0) + 1

            # Display the word counts
            print("\nWord Count:")
            for word, count in sorted(word_count.items()):
                print(f"{word}: {count}")

    except FileNotFoundError:
        print("Error: File not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

count_words('sample.txt')
