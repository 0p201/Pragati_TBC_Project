import os
import csv

print(f"Current working directory: {os.getcwd()}")
print(f"Files in directory: {os.listdir()}")  # Add this to debug

def display_csv(filename):
    try:
        with open(filename, newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            
            # Read and display headers
            headers = next(reader, None)
            if headers:
                print(f"{' | '.join(headers)}")
                print('-' * 50)

            # Read and display the rows
            for row in reader:
                print(f"{' | '.join(row)}")
    except FileNotFoundError:
        print(f"Error: The CSV file was not found at: {filename}")
        print(f"Current directory contents: {os.listdir(os.path.dirname(filename) or '.')}")
    except Exception as e:
        print(f"An error occurred: {e}")

# Correct way to call the function
csv_path = '/Users/suraj/Desktop/ASSIGNMENT_3/Question4/data.csv'
display_csv(csv_path)