''' The perimeter of a rectangle with length 9 & width 6 '''
length = 9
width = 6
perimeter = 2*(length+width)
print("The perimeter of rectangle is",perimeter)